var mapsList = [];
var mapHome = {
	lat: 48.853,
	lng: 2.35,
	zoom: 4
};

var DISCLAIMER_ID_ROOT = "disclaimer-open-btn-footer";
// dict of all side panel object pointers - Supports multiple widget instances on the same page
var _leftSideBars = new Map(); 

// For organization that we cannot resolve its address,
// we force then arbitrary the location to Paris, to show them on the map anyway
var UNDEFINED_ADDRESS = {
	lat: 48.853,
	lon: 2.35,
};

/**
 * debug log
 * @param s
 * @returns
 */
function trace(s) {
	var log_container = document.getElementById('log-container');
	if (log_container) {
		var div = document.createElement('div');
		div.innerHTML = s;
		log_container.appendChild(div);
	}
}

/**
 * Focus on a particular organization (based on org rcn) and zoom as close as passed in parameter
 * @param map - Targeted map
 * @param rcn - RCN of the organization
 * @param level - level to zoom to
 * @expand expand - true if we want to open the org info box, false otherwise
 * @returns
 */
function focusOnOrg(map, rcn, zoom, expand) {

	// As defautl value in function signature is not recognized by IE11 (OP) , 
	// old method has to be applied as workaround
	zoom = (typeof zoom !== 'undefined') ? zoom : map.getZoom();
	expand = (typeof expand !== 'undefined') ? expand : false;
	
	// Retrieve the organization coordinates
	var theMarker = null; // Default = Paris coords
	
	map.eachLayer(function (layer) { 
		if ( (typeof layer.options !== 'undefined')
			&& (typeof layer.options.orgRcn !== 'undefined')
			&& (parseInt(layer.options.orgRcn) === rcn) ) 
		{
			theMarker = layer;
			return false; // Note: useless as map.eachLayer() does not control return of the function...
		}
	});

	// If marker found, move to it and fire infobox
	if (theMarker) {
		const coords = theMarker.getLatLng();
		jumpToMapLocation(map, coords.lat, coords.lng, zoom);
		if (expand === true) {
			theMarker.closePopup(); // Close previous popup if already open, otherwise the fire click will switch the popup off
			theMarker.fire('click');		
			theMarker.closeTooltip();
		}
	} else {
		console.log("Organization not found. Action skipped!");
	}
}

/**
 * debug geocoding
 * @param name
 * @param addr
 * @param msg
 */
function dumpGeocodingResult(name, addr, msg) {
	trace(JSON.stringify({
		name: {
			name: name,
			address: addr
		}
	}) + " => " + msg);
}

/**
 * Get the position of the map in the list of instantiated maps
 * @returns
 */
function getMapIndex(target) {
	var found = false,
		idx;
	for (idx = 0;
		((idx < mapsList.length) && (found == false)); idx++) {
		if (mapsList[idx].target == target)
			found = true;
	}
	if (found == true)
		idx--;
	else
		idx = -1;
	return idx;
}

/**
 * Delete instanciated map (if exists)
 * @returns
 */
function deleteMap(target) {
	var pos = getMapIndex(target);
	if (pos >= 0) {
		mapsList[pos].markers.clearLayers();
		mapsList[pos].map.remove();
		mapsList[pos].map = null;
		mapsList.splice(pos, 1);
	}
}

/**
 * 
 * @param targetid
 * @param xProjects - true if json includes multiple projects participants, false otherwise
 */
function initMap(targetid, xProjects, fullscreen) {

	deleteMap(targetid);

	// Create basic map using OpenStreetMap tiles
	var newMap = new L.Map(targetid, {
			center: [mapHome.lat, mapHome.lng],
			zoom: mapHome.zoom,
			attributionControl: false,
			zoomControl: false,
			scrollWheelZoom: false
		})
		.addLayer(new L.TileLayer(MAP_BACKGROUND_GISCO_STREET));
		
	// Place all markers into 1 single group to be able later to clean them easily
	// (update of the map)
	var newMarkersGroup = new L.FeatureGroup().addTo(newMap);

	// Place EC attributions
	var credits = translate('maplab.common.map_leaflet_copyright') + ' <a href="http://openstreetmap.org" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>' + ' ' + translate('maplab.common.map_contrib')
		+ ', ' + translate('maplab.common.map_credits') + ' <a href="http://ec.europa.eu/eurostat/web/gisco/overview" target="_blank" rel="noopener noreferrer">EC-GISCO</a>, ' + translate('maplab.common.map_gisco_copyright')
		+ ', <a id="' + DISCLAIMER_ID_ROOT + '" href="#disclaimer">' + translate('maplab.common.map_disclaimer') + '</a>';

	var attributionControl = L.control.attribution({
		position: 'bottomright'
	});
	attributionControl.addAttribution(credits);
	newMap.addControl(attributionControl);

	// make a bar with the buttons
	var zoomBar = L.easyBar([
			L.easyButton({
		    	states: [{
		            stateName: 'zoom-in',        
		            icon:      '<big>+</big>',               
		            title:     'Zoom in',      
		            onClick: function(control, map){newMap.setZoom(map.getZoom() + 1);}
		        }]})
			, L.easyButton({
		    	states: [{
		            stateName: 'zoom-center',        
		            icon:      'far fa-dot-circle fa-lg',               
		            title:     'Center',      
		            onClick: function(control, map){newMap.setView([mapHome.lat, mapHome.lng], mapHome.zoom);}
		        }]})
			, L.easyButton({
		    	states: [{
		            stateName: 'zoom-out',        
		            icon:      '<big>-</big>',               
		            title:     'Zoom out',      
		            onClick: function(control, map){newMap.setZoom(map.getZoom() - 1);}
		        }]})
		    ], {position: 'bottomright'});
	
	zoomBar.addTo(newMap);

	if (fullscreen == true) {
		var fullScreenControl = L.control.fullscreen({
			position: 'bottomright'
		});
		fullScreenControl.addTo(newMap);
	}

	mapsList.push({
		target: targetid,
		map: newMap,
		markers: newMarkersGroup,
		m4prj: xProjects
	});

	// Make the map responsive according to parent
	$(window).on('orientationchange pageshow resize', function() {
		try {
			$("#map").height($(window).height());
			newMap.invalidateSize();
		} catch (error) {
			// catch & blocked leaflet exceptions when refreshing map based widget (does not occur systematically)
			// Workaround until issue is fixed in leaflet lib.
			//console.error(error);
		}
	}).trigger('resize');
	
	// Add hidden sidebar for disclaimer
	if (_leftSideBars.has(DISCLAIMER_ID_ROOT + "_" + targetid) == false){
		$("#" + targetid).append("<div id='sidebar'>"
			+ "<div><img src='" + getCordisHomeURL() + getDatavisRootFolder() + "/img/spinner.gif' class='SpinnerImage'></div>"
			+ "</div>"); 	
		var newbar = L.control.sidebar('sidebar', {
			position: 'left',
			closeButton: true,
		});
		newMap.addControl(newbar);
		var filePath = getCordisHomeURL() + getDatavisRootFolder() + "/language/" + getLanguage() + "/datavis-disclaimer.md";
		$.get(filePath)
			.done(function(result) {
				newbar.setContent(
					"<div><h4>" + translate("maplab.common.map_disclaimer") + "</h4></div>"
					+ '<div>' + result + '</div>');
			})
			.fail(function(jqXHR, textStatus, errorThrown) {
				newbar.setContent('Error loading ' + filePath + ' - ' + textStatus + ' - '+ errorThrown);
			});
		
		// Add dynamically a listener on the disclaimer link added above.
		$("#" + DISCLAIMER_ID_ROOT)[0].addEventListener("click", function(e) {
			e.preventDefault();
			_leftSideBars.get(DISCLAIMER_ID_ROOT + "_" + targetid).toggle();			
		});	
		
		_leftSideBars.set(DISCLAIMER_ID_ROOT + "_" + targetid, newbar);
	}
	
	// Click on the map
	newMap.on('click', function (e) {
		// Hide side panel(s) if visible
		_leftSideBars.forEach (function(value, key) {
  			if (value.isVisible() == true)
  				value.hide();
		});
	});

};

/**
 * 
 * @param e
 * @returns
 */
function dumpOpenStreetMapError(e) {
	var msg = translate('widget.error.osm_error') + ": " + e;
	console.log(msg);
}

/**
 * 
 * @param adr
 * @param city
 * @param country
 * @returns downgraded address to city level only
 */
function downgradeAddr2City(city, country) {
	var newAdr = '';
	city = city.toUpperCase();
	city = city.replace('CEDEX', '');
	city = city.replace(/[0-9]/g, '');
	city = city.replace(',', '');
	city = city.trim();
	newAdr = city + ", " + country;
	return newAdr;
}

/**
 * 
 * @param city
 * @param country
 * @returns downgraded address
 */
function downgradeAddr2Country(country) {
	var newAdr = '';
	country = country.replace(',', '');
	country = country.trim();
	newAdr = country;
	return newAdr;
}

/**
 * Create and display a info panel on top of the map
 * @param htmlContent: Formatted content for the panel
 * @returns
 */
function addTxtPanel(target, htmlContent, style) {
	var pos = getMapIndex(target);
	if (pos >= 0) {
		var infoCtrl = L.control({
			position: 'topleft'
		});
		var theMap = mapsList[pos].map;
		infoCtrl.onAdd = function(theMap) {
			var div = L.DomUtil.create('div', style);
			div.innerHTML = htmlContent;
			return div;
		};
		infoCtrl.addTo(mapsList[pos].map);
	}
}

/**
 * Create a text control on the map and place inthere a selection of project metadata
 * @param target - leaflet target where to add the panel
 * @param label - text to display
 * @param url - links to be associated to the displayed label (e.g. link)
 */
function showProjectInfo(target, label, url) {
	addTxtPanel(target, '<a target="_blank" rel="noopener noreferrer" href="' + url + '">' + label + '</a>', 'ProjectInfoDiv');
}

/**
 * Create a text control on the map and place inthere a error message
 * @param msg - textual error message to display
 */
function showErrorMessage(target, msg) {
	addTxtPanel(target, msg, 'ErrorMsgDiv');
}

/**
 * Get the contrib info and format in HTML its ID card
 * @param contribData - Contrib info
 * @returns HHTML snipet
 */
function GetContribSheet(target, cData, lat, lon, full) {

	var cCard = '';

	if (full == false) {
		cCard += ((cData.name != null) ? cData.name : '?');
	} else {
		// Build basic org block
		var cBlockOrg = translate("common.org_type_" + cData.type);
		cBlockOrg += '<b>' + ((cData.name != null) ? '<br/>' + cData.name : '');
		cBlockOrg += ( ((cData.street != null) && (cData.street != '')) ? '<br/>' + cData.street : '');
		cBlockOrg += ( ((cData.postalCode != null) && (cData.postalCode != '')) ? '<br/>' + cData.postalCode : '');
		cBlockOrg += ( ((cData.postBox != null) && (cData.postBox != '')) ? ' ' + cData.postBox : '');
		cBlockOrg += ( ((cData.city != null) && (cData.city != '')) ? ' ' + cData.city : '');

		if (cData.countryCode) {
			if (doAllowCountryFlag(cData.countryCode) == true) {
				cBlockOrg += '<br/>' + '<span class="flag-icon flag-icon-' +
				opCountryCode2ISO(cData.countryCode).toLowerCase() + '"></span>&nbsp;' +
				translate(opCountryCode2ISO(cData.countryCode), true);
			}
			else
				cBlockOrg += '<br/>' + translate(opCountryCode2ISO(cData.countryCode), true);
		}
		else			
			cBlockOrg +=  '&nbsp';
		
		cBlockOrg += '</b>';
		if (cData.url) {
			cBlockOrg += '<br/><span>' +
				'<a href="' + formatExternalURL(cData.url) + '" target="_blank" rel="noopener noreferrer">' + translate('common.website') +
				'&nbsp;&nbsp;<i class="fas fa-external-link-alt fa-lg" aria-hidden="true"></i>' +
				'</a></span>';
		}

		// If MapContrib about single project, show detailled organization card with address, website, etc
		if (mapsList[getMapIndex(target)].m4prj == false) {
			cCard = cBlockOrg;
			if ((cData.activityType) && (cData.activityType != ''))
				cCard += '<br/><br/>' + translate('common.activity_type') +
						'<br/><b>' + cData.activityType + '</b>';	
											
			// Create line detailling funding		
			cCard += '<br/><br/>' + '<table class="TableContrib"><tbody><tr>';
			
			// EU/EC contribution
			if ((cData.netEcContribution) && (isNumber(cData.netEcContribution) === true) /*&& (parseFloat(cData.netEcContribution) > 0)*/ ) {
				cCard += '<td>' + translate('common.net_eu_contribution') +
						'<br/><b>€ ' + formatNumber(cData.netEcContribution, -1, false) + '</b>'
						+ '</td>';	
			} // No netEcContribution, test ecContribution
			else if ((cData.ecContribution) && (isNumber(cData.ecContribution) === true) /*&& (parseFloat(cData.ecContribution) > 0)*/ ) {
				cCard += '<tr><td>' + translate('common.eu_contribution') +
						'<br/><b>€ ' + formatNumber(cData.ecContribution, -1, false) + '</b>'
						+ '</td>';	
			} else {
				cCard += '<tr><td>' + translate('common.eu_contribution') +
						'<br/><b> ' + translate('common.no_data') + '</b>'
						+ '</td>';						
			}
			
			// Total Cost
			if ((cData.active) && (cData.active === 'false')) { 
				// display nothing
			} else {
				if ((cData.totalCost) && (isNumber(cData.totalCost) === true) && (parseFloat(cData.totalCost) > 0)) {
					cCard += '<td>' + translate('common.total_cost') +
							'<br/><b>€ ' + formatNumber(cData.totalCost, -1, false) + '</b>'
							+ '</td>';	
				}
				else {
					cCard += '<td>' + translate('common.total_cost') +
							'<br/><b> ' + translate('common.no_data') + '</b>'
							+ '</td>';						
				}
			}
			
			// Close line detailling funding	
			cCard += '</tr></tbody></table>';
						
			// Geolocation lat, lon
			cCard += '<br/>' + translate('common.geolocation') +
				'<br/><b>' + lat + ' , ' + lon + '</b>';			

		} else {
			// If MapContrib about multiple projects, show compact organization card with project name, link to CORDIS, etc
			if ((cData.projectAcronym != null) && (cData.projectAcronym != 'undefined')) {
				cCard = translate('common.ctype_project') + '<br/>';
				cCard += '<b>' + cData.projectAcronym + '</b><br/>';
			}
			if (cData.projectUrl) {
				cCard += '<span>' +
					'<a href="' + cData.projectUrl + '" target="_blank" rel="noopener noreferrer">' + translate('common.view_on_cordis') +
					'&nbsp;&nbsp;<i class="fas fa-external-link-alt fa-lg" aria-hidden="true"></i>' +
					'</a></span><br/>';
			}

			cCard += '<br/>' + cBlockOrg;
		}
	}

	return (cCard);
}

/**
 * Get contributors' addresses and place it on the map after having geocoded them.
 * @param jsonData - List of contributors
 */
function showProjectContribOnMap(target, jsonData) {
	
	var geocode = function(rawData, level, adr, city, country) {

		// As defautl value in function signature is not recognized by IE11 (OP), 
		// old method has to be applied as workaround
		city = (typeof city !== 'undefined') ? city : '';
		country = (typeof country !== 'undefined') ? country : '';
		return $.ajax("https://gisco-services.ec.europa.eu/api", { 
			data: {
				q: adr,
				limit: 1 
			},
			crossDomain: true
		}).then(function(data) {
			if (!data || !data.features || (data.features.length == 0)) { 
				// If addr level X (full or downgraded) not found, try with only city and country
				if (level === 0) {
					// Resolution with level 0 failed
					dumpGeocodingResult(rawData.name, adr,"<font color='orange'>" + "WARNING geocoding error > try with downgraded version" + " (level " + (level + 1) + ")</font>");
					return geocode(rawData, level + 1, downgradeAddr2City(city, country), city, country);
				} else if (level === 1) {
					// Resolution with level 1 failed
					dumpGeocodingResult(rawData.name, adr,"<font color='orange'>" + "WARNING geocoding error > try with downgraded version" + " (level " + (level + 1) + ")</font>");
					return geocode(rawData, level + 1, downgradeAddr2Country(country));
				} else { 
					// Resolution with level 2 failed
					dumpGeocodingResult(rawData.name, adr,"<font color='red'>" + "ERROR geocoding error" + " (level " + level + ")</font>");
					//console.log("Impossible to resolve the location of the organization: " + rawData.name);
					return { raw: rawData, address: adr,	city: city,	country: country, 
							lat: UNDEFINED_ADDRESS.lat, 
							lon: UNDEFINED_ADDRESS.lon	
							};
				}
			} else {
				dumpGeocodingResult(rawData.name, adr, "<font color='green'>Geocoding OK</font>");
				return {raw: rawData, address: adr,	city: city,	country: country,
					lat: parseFloat(data.features[0].geometry.coordinates[1], 10), // WEBTOOLS
					lon: parseFloat(data.features[0].geometry.coordinates[0], 10) // WEBTOOLS
				};
			}
		}).fail(function(jqXHR, textStatus, errorThrown) {
			dumpGeocodingResult(rawData.name, adr, "<font color='red'>GISCO Geocoding ERROR</font>");
			//console.log("GISCO error (" + jqXHR.status + ") when resolving the location of the organization: " + rawData.name);
			return { raw: rawData, address: adr,	city: city,	country: country, 
					lat: UNDEFINED_ADDRESS.lat, 
					lon: UNDEFINED_ADDRESS.lon	
					};
		});
	};

	var pushMarker = function(lat, lon, type, target, data) {
		var detailSheet = GetContribSheet(target, data, lat, lon, true);
		var miniSheet = GetContribSheet(target, data, lat, lon, false);
		var markerIconClass = type.charAt(0).toUpperCase() + type.slice(1) + "DivIcon";
		var marker = new L.marker([lat, lon], {
			title: ((data.name != null) ? data.name : '?'),
			alt: ((data.name != null) ? data.name : '?'),
			orgName: ((data.name != null) ? data.name : '?'),
			orgRcn: ((data.rcn != null) ? data.rcn : '?'),
			icon: L.divIcon({
				iconSize: null,
				iconAnchor: [16, 32],
				className: markerIconClass
			})
		}).addTo(mapsList[getMapIndex(target)].map);
		marker.bindPopup(detailSheet);
		marker.bindTooltip(miniSheet);
		mapsList[getMapIndex(target)].markers.addLayer(marker);
	};

	try {
		var jsData = JSON.parse(jsonData).contributors;
		for (var key in jsData) {
			// Check embargo
			if (_EMBARGO_.includes(jsData[key].countryCode) == false) {
				// Recast address
				var POIcity = jsData[key].city;
				var POIcountry = translate(jsData[key].countryCode, true, true);
				var POIFulladdress = jsData[key].street
					//. ", " . jsData[key].postalCode // Geocoding works better without ZIP in OpenStreet
					+
					", " + jsData[key].city +
					", " + POIcountry;
	
				// If available, try with lat/lon info (pb, sometimes CORDIS coords are wrong)
				var POIlatlon = jsData[key].latlon;
	
				// Do not display **terminated** org
				if (jsData[key].terminated == "false") {
					var contribLocated = false;
					if (POIlatlon != "") {
						var coords = POIlatlon.split(",");
						try {
							dumpGeocodingResult(jsData[key].name, POIFulladdress, "<font color='gray'>Use coords data caching (" + coords[0] + "," + coords[1] + ")</font>");
							pushMarker(coords[0], coords[1], jsData[key].type, target, jsData[key]);
							contribLocated = true;
						} catch (e) {
							//dumpOpenStreetMapError(e + " >> DB lat,lon for geocoding failled, look up for coords based on postal address...");
						}
					}
	
					// If not succeed to locate the contrib via its coords (or no coords available)
					// then, try with geocoding its address
					if (contribLocated == false) {
						// Get coords & place marker on the map						
						geocode(jsData[key], 0, POIFulladdress, POIcity, POIcountry).then(function(coords) {
							if (Object.getOwnPropertyNames(coords).length > 0) {
								try {
									pushMarker(coords.lat, coords.lon, coords.raw.type, target, coords.raw);
								} catch (e) {
									dumpOpenStreetMapError(e);
								}
							}
						});
					}
				}
			} 
		}
	} catch (e) {
		console.error("Error while processing JSON data = " + e);
		console.log("JSON = " + jsonData);
	}

};

/**
 * End of synchronous Ajax page loading
 */
$(document).one("ajaxStop", function() {
	for (var idx = 0;(idx < mapsList.length); idx++) {
		var bounds = mapsList[idx].markers.getBounds();
		if (bounds.isValid()) {
			mapsList[idx].map.fitBounds(bounds);
			if (mapsList[idx].markers.getLayers().length == 1)
				mapsList[idx].map.setZoom(mapHome.zoom + 3);
		}
	}
});
