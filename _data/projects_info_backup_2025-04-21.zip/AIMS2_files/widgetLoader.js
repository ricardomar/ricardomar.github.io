//var $; // noconflict reference to jquery

// Cache data en ensure compatibility bwt Datavis main engine and widget engine (shared code)
var _JS_LANG_ = "en";    
var _VERSION_ = "?";
var _EMBARGO_ = [];

/**
 * 
 */
function trace(s) {
	var log_container = document.getElementById('log-container');
	if (log_container) {
		var div = document.createElement('div');
		div.innerHTML = s;
		log_container.appendChild(div);
	}
	//console.log(s);
}

/**
 * 
 * @param root
 */
function loadEmbargoData(root) {
	// Use JSONP technic and $.getJSON to get compatible with CORS when used by widget engine
	var jsonpURL = root + "/widget/api/getJsonpRsc.php" +
		"?lv=" + "" +
		"&rsc=" + "embargo" +
		"&callback=?";

	// Set the global ajax configs to synchronous 
	// To be sure that all resources will be loaded when requested further
	$.ajaxSetup({
		async: false
	});

	$.getJSON(jsonpURL, function(data) {
		
		_EMBARGO_ = data["countries"];
		//console.log("EMBARGO = " +  _EMBARGO_);
		
		if (getDebugMode() == true) {
			console.log(">>>>> INFO : resource file <" + jsonpURL + "> loaded OK");
		}
	}).fail(function(jqxhr, textStatus, error) {
		console.log(">>>>> ERROR : Failed loading resource file <" + jsonpURL + "> / message = " + textStatus + ", code=" + error);
	});

	// Restore global ajax configs to default 
	$.ajaxSetup({
		async: true
	});
}

function loadDatavisVersion(root) {
	// Use JSONP technic and $.getJSON to get compatible with CORS when used by widget engine
	var jsonpURL = root + "/widget/api/getVersion.php?callback=?";
	$.ajaxSetup({
		async: false
	});

	$.getJSON(jsonpURL, function(data) {
		_VERSION_ = data;
		//console.log("VERSION = " +  _VERSION_);
		if (getDebugMode() == true) {
			console.log(">>>>> INFO : resource file <" + jsonpURL + "> loaded OK");
		}
	}).fail(function(jqxhr, textStatus, error) {
		console.log(">>>>> ERROR : Failed loading resource file <" + jsonpURL + "> / message = " + textStatus + ", code=" + error);
	});

	// Restore global ajax configs to default 
	$.ajaxSetup({
		async: true
	});
}

/**
 * Loading the widget and all its dependencies
 */
(function() {

	var jqueryPath = "/lib/jquery-3.7.1/jquery-3.7.1.min.js"; // to be dynamically completed with pDatavisRoot path value
	var jqueryVersion = "3.7.1";
	var boostrapJSPath = "/lib/bootstrap-4.6.2/js/bootstrap.bundle.min.js"; // to be dynamically completed with pDatavisRoot path value
	var boostrapCSSPath = "/lib/bootstrap-4.6.2/css/bootstrap.min.css"; // to be dynamically completed with pDatavisRoot path value
	var scriptName = "widgetLoader.js"; //name of this script, used to get reference to own tag
	var scriptTag; // reference to the html script tag
	var pCssPrefix = "";
	var pTargetDiv, pCssFile, pDatavisRoot, pLv = 'en';

	// Search and get reference to self (scriptTag) 
	var allScripts = document.getElementsByTagName('script');
	var targetScripts = [];
	for (var i in allScripts) {
		var name = allScripts[i].src;
		if (name && name.indexOf(scriptName) > 0) {
			targetScripts.push(allScripts[i]);
		}
	}
	scriptTag = targetScripts[targetScripts.length - 1]; // Get current script 
	pDatavisRoot = scriptTag.src.split("/widget")[0];

	// Update all script local refs with the actual hosting server URL
	if (pDatavisRoot) {
		jqueryPath = pDatavisRoot + jqueryPath;
		boostrapJSPath = pDatavisRoot + boostrapJSPath;
		boostrapCSSPath = pDatavisRoot + boostrapCSSPath;
	} else {
		throw new Error("Hoster parameter is missing!");
	}

	// Collect special parameters (from data-* attributes)
	if (scriptTag.dataset.target)
		pTargetDiv = scriptTag.dataset.target;
	if (scriptTag.dataset.css)
		pCssFile = scriptTag.dataset.css;
	if (scriptTag.dataset.prefix)
		pCssPrefix = scriptTag.dataset.prefix;
	if (scriptTag.dataset.lv)
		pLv = scriptTag.dataset.lv;

	function isScriptLoaded(src) {
		var isLoaded = document.querySelector('script[src="' + src + '"]') ? true : false;
		trace('>' + src + ' already loaded ? >> ' + isLoaded);
		return isLoaded;
	}

	// Helper function to load external scripts or css 
	function injectFile(type, href) {
		var link_tag;
		if (type == 'js') {
			//if (isScriptLoaded(href)==false) 
			if (true)
				return new Promise(function(resolve, reject) {
					link_tag = document.createElement('script');
					link_tag.setAttribute("type", "text/javascript");
					link_tag.setAttribute("src", href);
					link_tag.setAttribute("async", true);
					link_tag.onload = resolve;
					link_tag.onerror = reject;
					(document.getElementsByTagName("head")[0] || document.documentElement).appendChild(link_tag);
					trace("JS " + href + " injected!");
				});
			else
				return new Promise(function(resolve, reject) {});

		} else {
			return new Promise(function(resolve, reject) {
				link_tag = document.createElement('link');
				link_tag.setAttribute("type", "text/css");
				link_tag.setAttribute("rel", "stylesheet");
				link_tag.setAttribute("href", href);
				link_tag.onload = resolve;
				link_tag.onerror = reject;
				(document.getElementsByTagName("head")[0] || document.documentElement).appendChild(link_tag);
				trace("CSS " + href + " injected!");
			});
		}
	}

	// Test of widget require Leaflet lib+ext to be loaded
	function doRequireLeaflet(type, output) {
		var req = false;
		if (type) {
			if (type == 'project-contrib-map')
				req = true;
			else if ((type == 'search-html') && (output == 'map'))
				req = true;
		}
		//trace("Requires Leaflet lib = " + req);
		return req;
	}

	// Test of widget need pagination lib+ext to be loaded
	function doRequirePagin(type, output) {
		var req = false;
		if ((type) && (type == 'search-html') && (output == 'table'))
			req = true;
		//trace("Requires pagination lib = " + req);
		return req;
	}

	// Test of widget need bootstrap lib+ext to be loaded
	/*
    function doRequireBootstrap(type, output) {  
    		req = false;
    		if ((type) && (type == 'search-html') && ((output == 'table') || (output == 'carousel')) )
			req = true;
		//trace("Requires bootstrap lib = " + req);
    		return req;
    }
    */

	// **************
	// Main
	// **************

	// Orchestrate asynchronous lib load & specialized scripts according to the type widget to render
	var promises = [];
	if ((window.jQuery === undefined) || (window.jQuery.fn.jquery !== jqueryVersion)) { // Load JQuery if necessary
		promises.push(injectFile("js", jqueryPath));
	} else {
		trace("JQuery is already loaded, dynamic injection skipped");
	}
	Promise.all(promises).then(function() {
		/*
	    // Load Bootstrap if necessary
		promises.length = 0;
		if (doRequireBootstrap(scriptTag.dataset.type, scriptTag.dataset.output) == true) {
			if (typeof($.fn.popover) == 'undefined') {
		    		promises.push(injectFile("css", boostrapCSSPath));
	    			promises.push(injectFile("js", boostrapJSPath));
			} else {
	    			trace("Bootstrap is already loaded, dynamic injection skipped");
			}
		}
    
		Promise.all(promises).then(function() {
			trace("Root bunch of promises were kept");               	
		});
    })
    	.then(function() { 
    	*/
		promises.length = 0;
		promises.push(injectFile("js", pDatavisRoot + '/js/systemUtil.js'));
		promises.push(injectFile("js", pDatavisRoot + '/js/language.js'));
		promises.push(injectFile("js", pDatavisRoot + '/widget/js/widgetManagement.js'));

		promises.push(injectFile("css", pDatavisRoot + '/lib/fontawesome-free-6.6.0/css/all.min.css'));
		promises.push(injectFile("css", pDatavisRoot + '/lib/flag-icon-css-3.1.0/css/flag-icon.min.css'));

		if (pCssFile != null)
			promises.push(injectFile("css", pCssFile));

		if (doRequireLeaflet(scriptTag.dataset.type, scriptTag.dataset.output) == true) {
			promises.push(injectFile("css", pDatavisRoot + '/lib/leaflet-1.7.1/leaflet.css'));
			promises.push(injectFile("css", pDatavisRoot + '/lib/leaflet-ext-fullscreen-1.0.2/dist/leaflet.fullscreen.css'));
			promises.push(injectFile("css", pDatavisRoot + '/lib/leaflet-add-easybutton-2.3.0/src/easy-button.css'));

			promises.push(injectFile("js", pDatavisRoot + '/lib/leaflet-1.7.1/leaflet.js'));
		}
		Promise.all(promises).then(function() {
				trace("First bunch of promises were kept!");
				promises.length = 0;
				if (doRequireLeaflet(scriptTag.dataset.type, scriptTag.dataset.output) == true) {
					promises.push(injectFile("js", pDatavisRoot + '/lib/leaflet-add-easybutton-2.3.0/src/easy-button.js'));
					promises.push(injectFile("js", pDatavisRoot + '/lib/leaflet-ext-fullscreen-1.0.2/dist/leaflet.fullscreen.min.js'));
					
					promises.push(injectFile("css", pDatavisRoot + '/widget/lib/leaflet-sidebar-0.2.4/src/L.Control.Sidebar.css'));
					promises.push(injectFile("js", pDatavisRoot + '/widget/lib/leaflet-sidebar-0.2.4/src/L.Control.Sidebar.js'));
					
					Promise.all(promises).then(function() {
						trace("Second bunch of promises were kept");
					});
				}
			})
			.then(function() {
				promises.length = 0;
				if (doRequireLeaflet(scriptTag.dataset.type, scriptTag.dataset.output) == true) {
					promises.push(injectFile("js", pDatavisRoot + '/widget/js/widgetMapContrib.js'));
				}
				if (doRequirePagin(scriptTag.dataset.type, scriptTag.dataset.output) == true) {
					promises.push(injectFile("js", pDatavisRoot + '/lib/simplepagination-1.6/jquery.simplePagination.js'));
				}
				Promise.all(promises).then(function() {
					trace("Third bunch of promises were kept");
				});
			})
			.then(function() {
				promises.length = 0;
				trace("ALL promises were kept, render the widget...");

				// Trace info (verbose/debug)
				trace("---------------------");
				trace("Render widget...");
				trace(">Root URL    = " + pDatavisRoot);
				trace(">jqueryPath  = " + jqueryPath);
				trace("--Widget--");
				trace(">Params     =" + JSON.stringify(scriptTag.dataset));
				trace(">CSS file   = " + ((pCssFile == null) ? "None" : pCssFile));
				trace(">CSS Prefix = " + ((pCssPrefix == "") ? "None" : pCssPrefix));
				trace(">Target div = " + ((pTargetDiv == null) ? "None" : pTargetDiv));
				trace(">Language   = " + pLv);
				trace("---------------------");

				// Complete & convert DOMStringMap to easier/standard object to deal with
				scriptTag.dataset.rootUrl = pDatavisRoot;
				var arrData = JSON.stringify(scriptTag.dataset);

				loadEmbargoData(pDatavisRoot);
				loadDatavisVersion(pDatavisRoot);
				setLanguage(pLv, pDatavisRoot, true);
				runWidget(_ACTION_RUN, pTargetDiv, pCssPrefix, pDatavisRoot, arrData);
			})
			.catch(function(error) {
				console.log(error);
				console.error('Error: Widget cannot be loaded properly. Action aborted!');
			});
	})
})();