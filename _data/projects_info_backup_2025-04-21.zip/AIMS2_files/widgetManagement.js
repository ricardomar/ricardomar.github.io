var _ACTION_PREVIEW = 'preview';
var _ACTION_RUN = 'run';
var _ACTION_UPDATE = 'update';
var _ACTION_GETCODE = 'getcode';
var _CORE_EXT = '-core';

// Run the widget 
function runWidget(action, target, prefix, rootUrl, config) {
	$(document).ready(function($) {
		// Toggle loading spinner
		if (target != null) {
			var div = null;
			if (action != _ACTION_UPDATE)
				div = document.getElementById(target);
			else
				div = document.getElementById(target + _CORE_EXT);

			if (div) {
				div.innerHTML = '<div class="' + ((prefix === undefined) ? '' : prefix) + 'SpinnerDiv' + '">' +
					'<img src="' + rootUrl + "/img/spinner.gif" + '" class="' + ((prefix === undefined) ? '' : prefix) + 'SpinnerImage">' +
					'</div>';
			}
		}

		var arr_config = JSON.parse(config);

		var jsonpURL = rootUrl + "/widget/api/renderWidget.php?action=" + action;
		for (var pKey in arr_config) {
			if (arr_config[pKey])
				jsonpURL += "&" + pKey + "=" + encodeURIComponent(arr_config[pKey]);
		}
		jsonpURL += "&callback=?";

		$.getJSON(jsonpURL, function(result) {
			if (target != null) {
				if (action != _ACTION_UPDATE)
					$("#" + target).html(result); // Set all
				else
					$("#" + target + _CORE_EXT).html(result); // Update core part only	

				$("#" + target).attr("wConfig", config); // Save widget config in data store as string
			} else
				alert(translate('widget.error.target_missing') + " (" + target + ")");
		});
	});
}

// Manage search result widget pagination
function setSearchResultPagination(pWidgetDiv, pPaginDiv, nbItem, itemPage, curPage) {
	$(document).ready(function($) {
		//console.log("Set pagination in " + pWidgetDiv + "/" + pPaginDiv + " for a total of " + nbItem + " items and " + itemPage + " / page (current = " + curPage + ")...");		
		$("#" + pPaginDiv).pagination({
			items: nbItem,
			itemsOnPage: itemPage,
			displayedPages: 3,
			currentPage: curPage,
			cssStyle: 'pagination-light-theme',
			prevText: "<<",
			nextText: ">>",
			onPageClick: function(pageNumber, event) {
				var config = $("#" + pWidgetDiv).attr("wConfig"); // Recover & update widget config from data store	
				var wConfig = JSON.parse(config);
				wConfig.page = pageNumber; // Update next page number
				runWidget(_ACTION_UPDATE, wConfig.target, wConfig.prefix, wConfig.rootUrl, JSON.stringify(wConfig));
			}
		});
	});
}