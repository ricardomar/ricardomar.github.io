var DEFAULT_LANGUAGE = 'en';
var LANGUAGE_KEY = '_LANGUAGE_';
var LABELS_CACHE_KEY = '_LABELS_CAHE_';
var LABELS_CACHE_VERSION_KEY = '_LABELS_CAHE_VERSION_';
var COUNTRIES_CACHE_KEY = '_COUNTRIES_CACHE';
var COUNTRIES_NATIVE_CACHE_KEY = '_COUNTRIES_NATIVE_CACHE';

var LABELS = {};
var COUNTRIES = {};
var COUNTRIES_NATIVE = {};

/**
 * Load the given JSON resource file
 * @param rscPath : Path of the resource
 * @param rscLang : Language code of the resource
 * @param rscFilename : File name of the resource
 * @param langStorageKey : Session cache entry key for the language code
 * @param rscStorageKey : Session cache entry key for the resource data
 * @param boolean sessionAdd - true if to add new content to existing one, false if to reset with new content
 * @returns
 */
function loadLanguageResource(rscPath, rscLang, rscFilename, langStorageKey, rscStorageKey, sessionAdd) {
	// As defautl value in function signature is not recognized by IE11 (OP) , 
	// old method has to be applied as workaround
	sessionAdd = (typeof sessionAdd !== 'undefined') ? sessionAdd : false;
	
	var rscFilePath = rscPath + "/language/" + rscLang + "/" + rscFilename + ".json";
	if (rscLang === "")
		rscFilePath = rscPath + "/language/" + rscFilename + ".json";
	
	if (getDebugMode() === true) { 
		console.log("loadLanguageResource(" + rscFilePath + ")..."); 
	}
	
	$.ajax({
	    url: rscFilePath,
	    async: false,
	    type: "GET",
	    dataType: "json",
	    success: function(data) {
			if (langStorageKey != null) {
				sessionStorage.setItem(langStorageKey, rscLang);
			}
			if (rscStorageKey !== null) {			
				if (sessionAdd === true) { // add
					var content = JSON.parse(sessionStorage.getItem(rscStorageKey));
					content = $.extend(content, data);
					sessionStorage.setItem(rscStorageKey,  JSON.stringify(content)); 
				}
				else { // Reset
					sessionStorage.setItem(rscStorageKey, JSON.stringify(data)); 
				}
			}
			
			
			if (getDebugMode() === true) {
				console.log(">>>>> INFO  : resource file <" + rscFilePath + "> Loaded OK");
			}
	    },
	    error:function(message) {
			if (langStorageKey != null) {
				sessionStorage.setItem(langStorageKey, "error");
			}
			if (rscStorageKey != null) {
				sessionStorage.setItem(rscStorageKey, JSON.stringify({}));	
			}
			console.error(">>>>> ERROR : Failed loading resource file <" + rscFilePath +  "> / message = " + JSON.stringify(message));
		}
	});	    	
}

/**
 * Load the given JSON resource file
 * @param rscPath : Path of the resource
 * @param rscLang : Language code of the resource
 * @param rscFilename : File name of the resource
 * @param langStorageKey : Session cache entry key for the language code
 * @param rscStorageKey : Session cache entry key for the resource data
 * @param boolean sessionAdd - true if to add new content to existing one, false if to reset with new content
 * @returns
 */
function loadJSONPLanguageResource(rscPath, rscLang, rscFilename, langStorageKey, rscStorageKey, sessionAdd) {
	// Load labels files
	// Use JSONP technic and $.getJSON to get compatible with CORS when used by widget engine
	var jsonpURL = rscPath + "/widget/api/getJsonpRsc.php" +
		"?lv=" + rscLang +
		"&rsc=" + rscFilename +
		"&callback=?";

	if (getDebugMode() === true) { 
		console.log("loadJSONPLanguageResource(" + jsonpURL + ")..."); 
	}

	// Set the global ajax configs to synchronous 
	// To be sure that all resources will be loaded when requested further
	$.ajaxSetup({
		async: false
	});

	$.getJSON(jsonpURL, function(data) {
		if (langStorageKey !== null) {
			sessionStorage.setItem(langStorageKey, rscLang);
		}
		if (rscStorageKey !== null) {			
			if (sessionAdd === true) { // add
				var content = JSON.parse(sessionStorage.getItem(rscStorageKey));
				content = $.extend(content, data);
				sessionStorage.setItem(rscStorageKey,  JSON.stringify(content)); 
			}
			else { // Reset
				sessionStorage.setItem(rscStorageKey, JSON.stringify(data)); 
			}
		}
		if (getDebugMode() === true) {
			console.log(">>>>> INFO : resource file <" + jsonpURL + "> loaded OK");
		}
	}).fail(function(jqxhr, textStatus, error) {
		if (langStorageKey !== null) {
			sessionStorage.setItem(langStorageKey, "error");
		}
		if (rscStorageKey !== null) {
			sessionStorage.setItem(rscStorageKey, JSON.stringify({}));
		}
		console.log(">>>>> ERROR : Failed loading resource file <" + jsonpURL + "> / message = " + textStatus + ", code=" + error);
	});

	// Restore global ajax configs to default 
	$.ajaxSetup({
		async: true
	});
}

/**
 * Set the user interface language
 * @param string lang - language ISO code (2 pos)
 */
function setLanguage(lang, path, fromWidget) {
	// As defautl value in function signature is not recognized by IE11 (OP) , 
	// old method has to be applied as workaround
	path = (typeof path !== 'undefined') ? path : '.';
	fromWidget = (typeof fromWidget !== 'undefined') ? fromWidget : false;
	
	if (getDebugMode() == true) {
		console.log("setLanguage(" + lang + "," + path + "," + fromWidget + ")");
		console.log("before loading / LABELS.length: " + Object.keys(LABELS).length);
		console.log("before loading / COUNTRIES.length: " + Object.keys(COUNTRIES).length);
		console.log("before loading / COUNTRIES_NATIVE.length: " + Object.keys(COUNTRIES_NATIVE).length);		
		console.log("before loading / CACHE.lv = " + sessionStorage.getItem(LANGUAGE_KEY));
		console.log("before loading / CACHE_LABELS.length: " + ((sessionStorage.getItem(LABELS_CACHE_KEY) === null) ? 'null' : sessionStorage.getItem(LABELS_CACHE_KEY).length));
		console.log("before loading / CACHE_COUNTRIES.length: " + ((sessionStorage.getItem(COUNTRIES_CACHE_KEY) === null) ? 'null' : sessionStorage.getItem(COUNTRIES_CACHE_KEY).length));
		console.log("before loading / CACHE_COUNTRIES_NATIVE.length: " + ((sessionStorage.getItem(COUNTRIES_NATIVE_CACHE_KEY) === null) ? 'null' : sessionStorage.getItem(COUNTRIES_NATIVE_CACHE_KEY).length));
	}

	_JS_LANG_ = lang; // Cache new language en ensure compatibility bwt Datavis main engine and widget engine (shared code)
	
	if (typeof sessionStorage !== 'undefined') { // Check broswer compatibility
		if ((lang != sessionStorage.getItem(LANGUAGE_KEY)) || (sessionStorage.getItem(LABELS_CACHE_KEY) === null) || (sessionStorage.getItem(LABELS_CACHE_KEY).length === 0) // No cache or change vl
				|| (sessionStorage.getItem(LABELS_CACHE_VERSION_KEY) === null) || (sessionStorage.getItem(LABELS_CACHE_VERSION_KEY) !== _VERSION_ )) // new Datavis version
		{

			if (fromWidget == true) {
				loadJSONPLanguageResource(path, lang, "lab-common", LANGUAGE_KEY, LABELS_CACHE_KEY, false);
				loadJSONPLanguageResource(path, lang, "countries", null, COUNTRIES_CACHE_KEY, false);
				loadJSONPLanguageResource(path, "", "countries_native", null, COUNTRIES_NATIVE_CACHE_KEY, false);				
				loadJSONPLanguageResource(path, lang, "lab-weblab", null, LABELS_CACHE_KEY, true);
				loadJSONPLanguageResource(path, lang, "lab-p2co", null, LABELS_CACHE_KEY, true);
				loadJSONPLanguageResource(path, lang, "lab-pcontrib", null, LABELS_CACHE_KEY, true);
			} else {
				loadLanguageResource(path, lang, "lab-common", LANGUAGE_KEY, LABELS_CACHE_KEY, false);
				loadLanguageResource(path, lang, "countries", null, COUNTRIES_CACHE_KEY, false);		
				loadLanguageResource(path, "", "countries_native", null, COUNTRIES_NATIVE_CACHE_KEY, false);		
				loadLanguageResource(path, lang, "lab-weblab", null, LABELS_CACHE_KEY, true);
				loadLanguageResource(path, lang, "lab-p2co", null, LABELS_CACHE_KEY, true);
				loadLanguageResource(path, lang, "lab-pcontrib", null, LABELS_CACHE_KEY, true);
			}
			
			sessionStorage.setItem(LABELS_CACHE_VERSION_KEY, _VERSION_); 
			
		} else if (Object.keys(LABELS).length === 0) {
			// To void reloading the translation rsc on every single page,
			// we maintain a cache in session and reload only when required.
			LABELS = JSON.parse(sessionStorage.getItem(LABELS_CACHE_KEY));
			COUNTRIES = JSON.parse(sessionStorage.getItem(COUNTRIES_CACHE_KEY));
			COUNTRIES_NATIVE = JSON.parse(sessionStorage.getItem(COUNTRIES_NATIVE_CACHE_KEY));
			if (getDebugMode() === true) {
				console.log(">>>>> No reload of the rsc file, reload from cache instead");
			}
		} else {
			if (getDebugMode() === true) {
				console.log(">>>>> reload/refresh SKIPPED");
			}
		}

		if (getDebugMode() === true) {
			console.log(">after loading / LABELS.length: " + Object.keys(LABELS).length);
			console.log(">after loading / COUNTRIES.length: " + Object.keys(COUNTRIES).length);
			console.log(">after loading / COUNTRIES_NATIVE.length: " + Object.keys(COUNTRIES_NATIVE).length);			
			console.log(">after loading / CACHE.lv = " + sessionStorage.getItem(LANGUAGE_KEY));
			console.log("-------------------------------");
			console.log(">after loading / CHECKING translation of a label (wizard.form.config_help) " + translate("wizard.form.config_help"));
			console.log(">after loading / CHECKING translation of a country (FI): " + translate("FI", true));
			console.log("-------------------------------");
		}
	} else
		alert("Your browser version is not supported. Please consider updating it for the best experience");
}

/**
 * Check if a language has been configured
 * @returns true/false
 */
function isLanguageCached() {
	return (!(Object.keys(LABELS).length == 0));
}

/**
 * Get the selected user language
 * @return language ISO code (2 pos)
 */
function getLanguage() {
	if (!isLanguageCached()) {
		var lang = (typeof _JS_LANG_ !== 'undefined') ? _JS_LANG_ : DEFAULT_LANGUAGE;
		setLanguage(lang);
	}
	return sessionStorage.getItem(LANGUAGE_KEY);
}

/**
 * Get countries list as array
 * @returns array of countries in the current language
 */
function getCountriesArray() {
	if (!isLanguageCached()) {
		var lang = (typeof _JS_LANG_ !== 'undefined') ? _JS_LANG_ : DEFAULT_LANGUAGE;
		setLanguage(lang);
	}
	return JSON.parse(sessionStorage.getItem(COUNTRIES_CACHE_KEY));
}

/**
 * Get countries list (in native language - al least for the 6 official CORDIS LV) as array
 * @returns array of countries in the current language
 */
function getCountriesNativeArray() {
	if (!isLanguageCached()) {
		var lang = (typeof _JS_LANG_ !== 'undefined') ? _JS_LANG_ : DEFAULT_LANGUAGE;
		setLanguage(lang);
	}
	return JSON.parse(sessionStorage.getItem(COUNTRIES_NATIVE_CACHE_KEY));
}

/**
 * Return the translation in current user language of the label for which the code is given
 * @param string code - code the label to translate
 * @return string - Translation
 */
function translate(code, isCountry, isNative) {
	// As defautl value in function signature is not recognized by IE11 (OP) , 
	// old method has to be applied as workaround
	isCountry = (typeof isCountry !== 'undefined') ? isCountry : false;
	isNative = (typeof isNative !== 'undefined') ? isNative : false;

	
	// Init cache in case there is nothing loaded yet
	getLanguage();

	var path = "";
	if (isCountry == false) 
		path = "LABELS." + code;
	else {
		if (isNative == false)
			path = "COUNTRIES." + code;
		else 
			path = "COUNTRIES_NATIVE." + code;
	}
	
	try {
		// Eval path in translation JSON
		var val = eval(path);
	} catch (e) {
		console.log("Error in translate(" + code + "): " + e.message);
	} finally {
		// If not found or not node leaf (eg. a branch and not a final label)
		if ((val == undefined) || (typeof val != 'string'))
			val = '__' + code + ' [' + getLanguage() + ']';
	}

	return (val);
}
