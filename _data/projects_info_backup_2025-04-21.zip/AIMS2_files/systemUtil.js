
var MAP_BACKGROUND_GISCO_STREET = "https://gisco-services.ec.europa.eu/maps/tiles/OSMCartoComposite/EPSG3857/{z}/{x}/{y}.png";
var MAP_BACKGROUND_GISCO_LGRAY = "https://gisco-services.ec.europa.eu/maps/tiles/CountriesWorld/EPSG3857/{z}/{x}/{y}.png";
var MAP_BACKGROUND_OSM_STREET = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
var MAP_BACKGROUND_OSM_LGRAY = "https://{s}.tiles.wmflabs.org/bw-mapnik/{z}/{x}/{y}.png";

/**
* Test and return true if the country flag can be displayed on map/widget/...
* (according to EC decision and guidelines)
 */
function doAllowCountryFlag(countryISO2code) {
	if ( (countryISO2code.toUpperCase() == "TW") 
	  || (countryISO2code.toUpperCase() == "XK")
	  || (countryISO2code.toUpperCase() == "PS")) {
	  return false;
	} else {
	  return true;		
	}  
}

/**
 * Returns a random integer between min (inclusive) and max (inclusive) Using
 * Math.round() will give you a non-uniform distribution!
 */
function getRandomInt(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Format large number as "easy to read" string
 * 
 * @param value : amount to format
 * @param round : Number of digit for rounding (-1 if no round)
 * @param abrev : true if thousands abreviation added
 * @param decim : symbol for decimal separator
 * @returns
 */
function prettifyNumber(value, round, abrev, decim) {
	var thousand = 1000;
	var million = 1000000;
	var billion = 1000000000;
	var trillion = 1000000000000;
	var retStr = '?';
	
	// If no rounding requested
	if (round == -1) {
		var parts = value.toString().split(".");
		// Place space as thousands separator
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " "); 
		// Pad décimal part with 0 if needed		
		if (!parts[1]) 
			parts[1] = "0";
		if (parts[1].length < 2)
			parts[1] = parts[1].padEnd(2, '0');
		// Reformat the final string according to given decimal separator
		retStr = parts.join(decim);
	} else {
		var dfactor = Math.pow(10, round);
		if (value < thousand) {
			retStr = String(value);
		} else if (value >= thousand && value < million) {
			retStr = Math.round(value / thousand * dfactor) / dfactor + ((abrev == true) ? ' K' : ' thousand');
		} else if (value >= million && value < billion) {
			retStr = Math.round(value / million * dfactor) / dfactor + ((abrev == true) ? ' M' : ' million');
		} else if (value >= billion && value < trillion) {
			retStr = Math.round(value / billion * dfactor) / dfactor + ((abrev == true) ? ' B' : ' billion');
		} else {
			retStr = Math.round(value / trillion * dfactor) / dfactor + ((abrev == true) ? ' T' : ' trillion');
		}
	}

	return retStr;
}

/**
 * Format number to be more lisible (in part. for large number)
 * 
 * @param value (string) - Value to format
 * @param round (integer) - Number of digit for rounding (-1 if no round)
 * @param abrev (boolean) - true if thousands abreviation added
 * @param decim (string) - Symbol for decimal separator 
 * @returns (string) - the formatted number
 */
function formatNumber(value, round, abrev, decim) {

	// As defautl value in function signature is not recognized by IE11 (OP) 
	// still,
	// old method has to be applied as workaround
	round = (typeof round !== 'undefined') ? round : 0;
	abrev = (typeof abrev !== 'undefined') ? abrev : false;
	decim = (typeof decim !== 'undefined') ? decim : ".";

	if (value)
		return (prettifyNumber(value, round, abrev, decim));
	else
		return (prettifyNumber(0.0, round, abrev, decim));
}

/***
 * Return true if parameter is a number
 * @param num - string to test
 * @returns True if string represent a number
 */
function isNumber(num) {
	return !isNaN(num)
}

/**
 * Function to get hex format a rgb colour
 * @param rgb triple "(x,yz)"
 * @returns Hex value
 */
function rgb2hex(rgb) {
	if (/^#[0-9A-F]{6}$/i.test(rgb)) return rgb;
	rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);

	function hex(x) {
		return ("0" + parseInt(x).toString(16)).slice(-2);
	}
	return "#" + hex(rgb[1]) + hex(rgb[2]) + hex(rgb[3]);
}

/**
 * Map OP country codes to ISO 3166-1
 * @param OPcode
 * @returns
 */
function opCountryCode2ISO(OPcode) {
	var isoCode = OPcode;
	switch (OPcode) {
		case 'uk':
		case 'UK':
			isoCode = 'GB';
			break;
		case 'el':
		case 'EL':
			isoCode = 'GR';
			break;
	}
	return isoCode;
}

/**
 * 
 * @returns true/false
 */
function getDebugMode() {
	if (typeof _JSDF_ === 'undefined') // If var undefined
		return false;
	else
		return _JSDF_;
}

/**
 * Build and return the URL of the given organization to the R&I dashboard
 * @returns URL
 */
function getRtdOrgDashURL(orgID) {
	return 'https://dashboard.tech.ec.europa.eu/qs_digit_dashboard_mt/public/sense/app/dc5f6f40-c9de-4c40-8648-015d6ff21342/sheet/3bcd6df0-d32a-4593-b4fa-0f9529c8ffb0/state/analysis/select/Organisation%20PIC/' + orgID;
}

/**
 * Build and return the URL of the given organization & Project contact form on FTOP
 * @returns URL
 */
function getOrgContactFormURL(orgID, projectID) {
	return 'https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/contact-form/PROJECT/' + orgID + '/' + projectID;
}

/**
 * Get the URL to CORDIS home page
 * @returns URL
 */
function getCordisHomeURL()  {
	return "https://cordis.europa.eu";
}

/**
 * Get the URL to CORDIS support page on Search syntax
 * @returns URL
 */
function getHelpOnSearchURL()  {
	return getCordisHomeURL() + "/about/search/" + getLanguage();
}

/**
 * Zoom on a map to the location (lat/lng) and zoom as close as passed in parameter
 * @param map - Targeted map
 * @param lat - lattitude to move to
 * @param lon - longitude to move to
 * @param zoom - level to zoom to
 * @returns
 */
function jumpToMapLocation(map, lat, lon, zoom) {

	// As defautl value in function signature is not recognized by IE11 (OP) , 
	// old method has to be applied as workaround
	zoom = (typeof zoom !== 'undefined') ? zoom : map.getZoom();

	var options = {};
	if ((typeof _JS_ANIM_FLAG_ !== 'undefined') && (_JS_ANIM_FLAG_ == true)) {
		options["animate"] = true;
		options["duration"] = 0.5;
	}

	map.panTo([lat, lon], options);
	map.setView([lat, lon], zoom, options);
}

/**
 * Format external URL
 * @param pUrl
 * @returns
 */
function formatExternalURL(pUrl) {
	//console.log("in = " + pUrl);
	//var fUrl = (pUrl.startsWith('http') || pUrl.startsWith('https')) ? pUrl : 'http://' + pUrl;
	//console.log("out = " + fUrl);
	//return (fUrl);
	return ((pUrl.startsWith('http') || pUrl.startsWith('https')) ? pUrl : 'http://' + pUrl);
}

/**
* Reuturn the name of the root folder for data visualisations
* Note: If modified, please also look at the .js version (Config.php > getDatavisRootFolder())
*/
function getDatavisRootFolder() {
	return '/datalab/visualisations';
}

/**
 * Analyze context of the user session and provide URL parameter to add systematically to an URL
 */
function getContextURLParameters(inclLanguage) {

	// As defautl value in function signature is not recognized by IE11 (OP) 
	// still,
	// old method has to be applied as workaround
	inclLanguage = (typeof inclLanguage !== 'undefined') ? inclLanguage : true;

	var urlParams = new URLSearchParams(window.location.href.split("?")[1]);
	var context = '';
	if ((typeof urlParams !== 'undefined')) {	
		if (urlParams.has('fullMenu') === true)
			context = 'fullMenu=' + urlParams.get('fullMenu');
			
		if ((inclLanguage === true) && (urlParams.has('lv') === true))
			context += '&lv=' + urlParams.get('lv');
	}
	return (context); 
}
