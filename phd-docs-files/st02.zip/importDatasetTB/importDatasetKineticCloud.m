function datasetKineticCloud= importDatasetKineticCloud(path)
    
    import jParserToolbox.*;
    extractedPath=extractPath(path);
       
    jParser=jKineticCloudParser(path);
    parsedFile=jParser.parseFile();
    
    sizeDataset=size(parsedFile,1); 
    
    datasetKineticCloud=struct;

    datasetKineticCloud.rawdata(sizeDataset).timestamp=0;
    datasetKineticCloud.rawdata(sizeDataset).path='';
    
    for i=1:sizeDataset          
        cloud_Path=[extractedPath,char(parsedFile(i).getPath())];             
        datasetKineticCloud.rawdata(i).timestamp=parsedFile(i).getTimestamp();               
        datasetKineticCloud.rawdata(i).path=cloud_Path;
    end