import serial
from math import *

class polhemus:	
	n=0
	n_port=4r.readline()
	sensors_data=[]
	port=0
	
	def __init__(self,n):
		try:
			self.n=n
			self.port = serial.Serial(self.n_port,baudrate=115200,bytesize=serial.EIGHTBITS,parity=serial.PARITY_NONE,stopbits=serial.STOPBITS_ONE,xonxoff=0,rtscts=0)	
			self.sensors_data=[]
		except:
			print "erro parte I"
			
			
		
	def getSingleDataRecordOutput(self):
		try:
			self.sensors_data=[]
			self.port.write("p")
			
			for i in range(self.n):
				temp=[]
				temp2=self.port.readline()
				temp.append(float(temp2[4:13]))
				temp.append(float(temp2[13:22]))
				temp.append(float(temp2[22:31]))
				temp.append(float(temp2[31:40]))
				temp.append(float(temp2[40:49]))
				temp.append(float(temp2[49:57]))
			
				self.sensors_data.append(temp)
		
			return self.sensors_data
		
		except:
			print "Erro parte II"
		
	
	def closePort(self):
		self.port.close()
