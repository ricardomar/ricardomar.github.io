from polhemus import *
from numpy import *
from math import *
import viz

viz.go()
liberty=polhemus(1)

lixo1=0
lixo2=0
lixo3=0

i=0
def Timer(num):
	global lixo1
	global lixo2
	global lixo3
	global i
	global liberty	
	sensors_data=liberty.getSingleDataRecordOutput()
	#print str(sensors_data[0][0]*2.54 )+'     '+str(sensors_data[1][0]*2.54)
	#print str(sensors_data[0][1]*2.54) +'     '+str(sensors_data[1][1]*2.54)
	#print str(sensors_data[0][2]*2.54) +'     '+str(sensors_data[1][2]*2.54)
	
	if i==0:
		lixo1=sensors_data[0][0]*2.54 
		lixo2=sensors_data[0][1]*2.54 
		lixo3=sensors_data[0][2]*2.54 
		i=1
		
	
	print lixo1-sensors_data[0][0]*2.54 
	print lixo2-sensors_data[0][1]*2.54 
	print lixo3-sensors_data[0][2]*2.54
	
	lixo1=sensors_data[0][0]*2.54 
	lixo2=sensors_data[0][1]*2.54 
	lixo3=sensors_data[0][2]*2.54 
	
	#print sensors_data[1]
	#print sensors_data[2]
	#print sensors_data[3]
	#print sensors_data[4]
	#print sensors_data[5]	




viz.callback(viz.TIMER_EVENT,Timer)
viz.starttimer(0,0.1,viz.FOREVER)


def onExit():
	global liberty
	liberty.closePort()
	
viz.callback(viz.EXIT_EVENT,onExit)