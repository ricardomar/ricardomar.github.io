import viz
import skeleton
viz.go()

model=viz.add('male.cfg',alpha=0.5)

vizact.onkeydown(' ',model.visible,viz.TOGGLE)
import vizcam
cam = vizcam.PivotNavigate(distance=3)
cam.centerNode(model)

skeleton.createSkeletonFullBody()


#viz.startlayer(viz.LINES)
#viz.linewidth(2)
#viz.pointsize(6)
#viz.vertexcolor(viz.RED)

#for i in range(23):
	#viz.vertex(0,0,0)
	#viz.vertex(0,0,0)

#skeleton=viz.endlayer()
#skeleton.dynamic()


