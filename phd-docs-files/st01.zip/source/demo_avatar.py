import viz
import vizmenu
import vizinfo

panel_left= vizinfo.add('')
panel_left.translate(0.05,0.95)
panel_left.alignment(vizinfo.UPPER_LEFT)

radio_button_01=panel_left.add(viz.RADIO,0,'Full Body   ')
radio_button_02=panel_left.add(viz.RADIO,0,'Hand         ')




viz.go()


#def onRadioButton(obj,state):
#	if obj==viz.VizRadioButton(9):		
#		full_body=viz.add('male.cfg')
#	elif obj==viz.VizRadioButton(13):
#		hand=viz.add('hand.cfg')

#viz.callback(viz.BUTTON_EVENT,onRadioButton)


import vizcam
vizcam.PivotNavigate()
n=vizcam.PivotNavigate()
n.setCenter([0,1,0])
n.setDistance(3)
