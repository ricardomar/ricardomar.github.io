import viz
viz.go()

def CreateSkeleton(avatar):
	
	points = []
	lines = []

	def traverse(bone):
		points.append(bone)
		for b in bone.getChildren():
			lines.append((bone,b))
			traverse(b)
			
	#Collect list of bones for drawing points and lines
	for b in avatar.getRootBoneList():
		traverse(b)

	#Create OTF object
	viz.startlayer(viz.LINES)
	viz.linewidth(2)
	viz.pointsize(6)
	viz.vertexcolor(viz.RED)

	for l in lines:
		viz.vertex(0,0,0)
		viz.vertex(0,0,0)

	viz.startlayer(viz.POINTS)

	for p in points:
		viz.vertex(0,0,0)

	skeleton = viz.endlayer()
	skeleton.dynamic()

	#Link each vertex to corresponding bone
	count = 0
	for b1,b2 in lines:
		viz.link(b1,skeleton.Vertex(count))
		count += 1
		viz.link(b2,skeleton.Vertex(count))
		count += 1

	for b in points:
		viz.link(b,skeleton.Vertex(count))
		count += 1

	return skeleton


#model = viz.add('male.cfg',alpha=0.7)
#model = viz.add('ricardo7.cfg')
model = viz.add('hand.cfg',alpha=0.5)
#model.setScale(7,7,7)
#model.state(2)

CreateSkeleton(model)

#Toggle avatar mesh on space key.
#onkeydown(' ',model.visible,viz.TOGGLE)

import vizcam
cam = vizcam.PivotNavigate(distance=8)
cam.centerNode(model)