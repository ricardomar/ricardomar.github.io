import viz
viz.go()


model = viz.add('male.cfg')
bone=model.getBone('skel_Neck')
model.setEuler(180,0,0,viz.ABS_GLOBAL)


viz.startlayer(viz.LINES)
viz.linewidth(2)
viz.pointsize(6)
viz.vertexcolor(viz.RED)

viz.vertex(0,0,0)
viz.vertex(5,0,0)

viz.startlayer(viz.POINTS)


skeleton = viz.endlayer()
skeleton.dynamic()
