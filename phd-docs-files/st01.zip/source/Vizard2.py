import viz
import skeleton
viz.go()

human=viz.add('hand.cfg',alpha=0.2)
#human.scale(3,3,3)

skeleton.createSkeletonHand()

import vizcam
cam = vizcam.PivotNavigate(distance=0.5)
cam.centerNode(human)
