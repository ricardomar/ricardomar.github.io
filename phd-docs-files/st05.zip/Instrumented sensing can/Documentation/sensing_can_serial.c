/*
 * Sensing object test code, using PEAK PCAN interface card
 *
 * (C) Shadow Robot Company, 2009.
 *
 * This code is example code and put into the public domain
 *
 * The Sensing Object streams data continuously from each of the six
 * faces. This programme receives the messages, identifies which face
 * they are from, and unpacks them. The results are stored in the
 * struct face corresponding to the face of the sensing object.
 *
 */
#include <errno.h>
#include <error.h>
#include <libpcan.h>
#include <stdio.h>
#include <fcntl.h>
#include <ncurses.h>

/* PEAK card has two devices: this is the port nearest the motherboard */
char * port = "/dev/pcan0";

HANDLE h;

/* This is the data returned by one of the faces.  
 *
 * data[0]..data[8] are the force sensors, data[9]..data[11] are the
 * accelerometers.
 * 
 * base is the base address of the face. 
 */

struct face {
  int data[12];
  unsigned int base;
  char * name;
};

int messages_seen[0x800];

/* Setup the base addresses for the faces of the object */
struct face object[6] = {
  { .base = 0x500, .name="green" },
  { .base = 0x520, .name="white" },
  { .base = 0x540, .name="orange" },
  { .base = 0x560, .name="blue" },
  { .base = 0x580, .name="red" },
  { .base = 0x5a0, .name="yellow" }
};

#define FACE_DATA_SIZE 12 // There are 12 data items sent by the face.

/* This is just for diagnostic purposes. In the real world you would want to store this data somewhere useful. */
void print_object(void) {
  int i,j;
  for (i=0; i<6; i++) {
    mvprintw(i+1,0,"%d: %s",i, object[i].name);
    /* The force sensors */
    mvprintw(i+1,12,"");
    for (j=0;j<9;j++) 
      printw(" %03x", object[i].data[j]);
    printw(":");
    /* The acceleration sensors */
    for (j=0;j<3;j++) 
      printw("%03x ", object[i].data[j+9]);
    clrtoeol();
  };
}

/* Call with a message that has just been received. */
void process_message(TPCANMsg *m) {
  int i,j;
  mvprintw(9,1,"ID=%x", m->ID); clrtoeol();
  messages_seen[m->ID]++;
  for (i=0; i<6; i++) {
    /* Search the faces until we find the one that matches this message */
    if ((object[i].base <= m->ID) && ((object[i].base+FACE_DATA_SIZE)>m->ID)) {
      /* The message contains LEN/2 16-bit data items. Unpack them and store them */
      for (j=0;j<m->LEN/2;j++) {
	unsigned int v;
	/* Convert the two bytes into an integer */
	v = m->DATA[j*2];
	v |= m->DATA[(j*2)+1]<<8;
	object[i].data[ m->ID - object[i].base + j] =v; 
      };
    };
  };
}


int list_messages(void) {
  int i;
  int count=0;
  for (i=0;i<0x800;i++) {
    if (messages_seen[i]) { 
      count++;
      printf("%04x: %12d  ", i, messages_seen[i]);
      if ((count%8)==0)
	printf("\n");
    };
  };
}

int main(int argc, char ** argv) {
  __u32 status;
  /* Open the CAN poer. */
  h = LINUX_CAN_Open(port, O_RDWR);
  if (!h) error(1,errno, "can't open %s", port);
  /* clear status */
  CAN_Status(h);
  /* Set it up for 1MBit */
  errno = CAN_Init(h, 0x14, 0);
  if (errno) error(1,errno, "CAN_Init");

  atexit(list_messages);

  initscr();
  cbreak();
  noecho();
  nodelay(stdscr, 1);
  clear();
   while (getch()!='q') {
     TPCANMsg m;
     /* Get a message */
     errno=CAN_Read(h, &m);
     if (errno) error(0,errno, "on CAN_read, continuing");
     else process_message(&m);
     /* Clear any status info */
     status = CAN_Status(h);
    if ((int)status < 0) {
      errno = nGetLastError();
      error(0,errno," CAN_Status()");
    } else
      mvprintw(10,0,"pending CAN status 0x%04x read.\n", (__u16)status); clrtoeol();
    print_object();
    refresh();
  };
   endwin();
   list_messages();
}

